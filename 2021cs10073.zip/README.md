Interface - 
1. variable declaration of form - "x1, x2, x3 = <expression> "  
2. for simplicity all variables are converted to rational under the hood. 
3. if one needs to update the value of a variable, then she has to redeclare the variable( in spirit of functional programming) . 
4. one can see the variable value by typing - printrat <variablename> for fractional normal form 
and printdec <variablename> for decimal normal form. 

references - ml lex and ml yacc documentation (have used some code as such)

--------------------------------------------------------------
pragmatic decisions (when using rational.sml without parsing) - 
1. we have declared the structure Rational to be abstract, thus to see a rational, use showRat or showDecimal on a rational. a rational can be generated from make_rat,rat,reci,fromDecimal. 
2. thorughout the library we have assumed that rational(x,y) is in std form, since it can only be obtained through make_rat, rat, reci, fromDecimal all of which use make_rat which converts the rational to fractional normal form.
--------------------------------------------------------------- 
(in grammars, we denote non terminals by <>)
grammar for rational numbers - 
<rational> -> <bigint> | <decimal> | ( <bigint>, <denum> ) 
<denum> -> <sign><d>
<d> -> digit <d> | nonzero
<bigint> -> <sign><digits> 
<digits> -> digit <digits> | digit 
<sign> -> + | ~ | null  

terminals - 1. digit - [0-9] 
            2. nonzero - [1-9] 
            2. null - epsilon 

-------------------------------------------------------------------
grammar for rational number expressions - 

<statement> -> <expression> | <declaration> | <print> | null 

<declaration> -> <var> equal <expression> | <var> comma <declaration> 

<print> -> printrat <var> | printdec <var> 

<expression> -> <expression> plus <term> | <expression> minus <term> | <term> 
<term> -> <factor>  mult <term> | <factor> div <term> | <factor> 
<factor> -> <var> | <rational> | tilde <var> | tilde <rational> | lparen <expression> rparen 

<var> -> alpha | alpha <var> 

terminals - plus - "+", minus - "-", mult - "*" , div - "/" , tilde - "~" , lparen - "(", rparen - ")" 
            printrat - "printrat", printdec - "printdec", equal - "=" , comma - "," null - epsilon 